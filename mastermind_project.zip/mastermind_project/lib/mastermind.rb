require_relative "code"

class Mastermind

end
